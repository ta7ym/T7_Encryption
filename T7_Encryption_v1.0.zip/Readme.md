#===========Important information===========#




Do not delete data folder!!!

If you delete data folder the program will not work !!

The solution : Go to my GitHup account and download the program again.




If the program does not work, visit my account on GitHup For get the compatible program of your Python version.




If there are any other problems, contact me via my email.




#===========Developer information===========#




Name : Taym AlBatoushi

Nickname : T7

Birthday : 2007/12/31

Email : taym.battoshi@gmail.com

Instagram , Telegram , facebook : ta7ym

Twitter : Tim_ALBatoushi

GitHub : https://github.com/ta7ym

From Syria




#==================Donat❤==================#




Bitcoin : 15Wf9rJSx94kb4cWKpt7ckM3t3TdWZ7rac


Litecoin : ltc1qjy7zr8and3ey8s2exnzc5z4lfm9r9ur40e3d2y


USDT (TRC20) : TQCwQoddNB7NdYu1R98RTKg6oDEBcp8UJK


Tron : TQCwQoddNB7NdYu1R98RTKg6oDEBcp8UJK




#===========================================#

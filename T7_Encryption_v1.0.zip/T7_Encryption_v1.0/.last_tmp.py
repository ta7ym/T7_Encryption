#=========Developer information=========#



"""

Name : Taym AlBatoushi

Nickname : T7

Birthday : 2007/12/31

Email : taym.battoshi@gmail.com

Instagram , Telegram , facebook : ta7ym

Twitter : Tim_ALBatoushi

GitHub : https://github.com/ta7ym

From Syria

"""



#=========Libraries Section=========#



import getpass
from os import system,remove,rmdir

try:

	from data import Kernel as T7

except:
	try:
		from data import Kernel311 as T7
	except:
		try:
			from data import Kernel39 as T7
		except:
			try:
				from data import Kernel36 as T7
			except:
				system("clear")

				print("This script not responds with your version of python\nUpdate Python or visit my account on GitHup to get the right script for your Python version\nMy account on GitHup : https://github.com/ta7ym")

				exit()





#=========Banner=========#




def Banner():



	print("\033[1;93m _____ _____ _____                             _   _")

	print("|_   _|___  | ____|_ __   ___ _ __ _   _ _ __ | |_(_) ___  _ __")

	print("  | |    / /|  _| | '_ \\ / __| '__| | | | '_ \\| __| |/ _ \\| '_ \\")

	print("  | |   / /_| |___| | | | (__| |  | |_| | |_) | |_| | (_) | | | |")

	print("  |_|  /_/(_)_____|_| |_|\\___|_|   \\__, | .__/ \\__|_|\\___/|_| |_|")

	print("                                   |___/|_|\033[1;92m")




def Options():
	print("\n[ 1 ] Encryption\n\n[ 2 ] Decryption\n\n[ 3 ] File encryption\n\n[ 4 ] Clear cache\n\n[ 5 ] Clear\n\n[ 0 ] Exit")




#=========File encryption=========#




def Selection_for_files():
	result = ""
	while True:
		ops = ("\n[ 1 ] Text Files\n\n[ 2 ] Other Files (mp3,mp4,png,PDF,And more)\n\n[ 3 ] Clear\n\n[ 0 ] Back")


		def Text_files_encryption():
		
			ops = ("\n[ Text file encryption ]\n\n[ 1 ] File Encryption\n\n[ 2 ] File Decryption\n\n[ 3 ] Clear\n\n[ 0 ] Back")

			while True:

				system("clear")

				Banner()
				print(ops)
				
				try:

					print (result)

				except:

					pass

				Select = input("\n\nSelect >>> ")

				system("clear")

				Banner()
				print(ops)

				if Select == "1":

					system("clear")

					Banner()

					file_path = input("\n\n\n\n\n\n\n\n\n\n\nEnter file path >>> ")
					result="\n\n\n\n\n\n\n\n\n\n\nEnter Password decryption for file >>> "
					system("clear")
					Banner()
					Owt_File=input("\n\n\n\n\n\n\n\n\n\n\nEnter a name for encrypted file >>> ")
					while True:
						system("clear")
						Banner()

						File_Password=getpass.getpass(result)

						if len(File_Password) < 6:
							result = "\n\n\n\n\n\n\n\n\n\n\nThe password must not be less than 6 Enter again >>> "

							continue

						else:

							break

					result="\n\n>>> "+T7.File_Encryption(file_path,File_Password,Owt_File)

					system("clear")

					Banner()




				elif Select == "2":

						system ("clear")

						Banner()


						file_path = input("\n\n\n\n\n\n\n\n\n\n\nEnter file path >>> ")

						system("clear")

						result="\n\n\n\n\n\n\n\n\n\n\nEnter password >>> "
						system("clear")
						Banner()
						Owt_File=input("\n\n\n\n\n\n\n\n\n\n\nEnter a name for decrypted file >>> ")
						while True:

							system("clear")

							Banner()

							File_Password = getpass.getpass(result)

							if len(File_Password) < 6:

								result = "\n\n\n\n\n\n\n\n\n\n\nThe password must not be less than 6 Enter again >>> "

							else:

								break

						result="\n\n>>> "+T7.File_Decryption(file_path,File_Password,Owt_File)
						system("clear")

						Banner()

						
						


				elif Select == "3":

					system("clear")

					result = ""

					Banner()

					print(ops)

				elif Select == "0":

					system("clear")

					Banner()

					Options()

					break


				else:

					result = "\n\n>>> Wrong selection"



		def Other_files():
			ops = ("\n[ Binary file encryption ]\n\n[ 1 ] File Encryption\n\n[ 2 ] File Decryption\n\n[ 3 ] Clear\n\n[ 0 ] Back")

			while True:

				system("clear")

				Banner()
				print(ops)
				
				try:

					print (result)

				except:

					pass

				Select = input("\n\nSelect >>> ")

				system("clear")

				Banner()
				print(ops)

				if Select == "1":

					system("clear")

					Banner()

					file_path = input("\n\n\n\n\n\n\n\n\n\n\nEnter file path >>> ")

					result="\n\n\n\n\n\n\n\n\n\n\nEnter Password decryption for file >>> "
					system("clear")
					Banner()
					Owt_File=input("\n\n\n\n\n\n\n\n\n\n\nEnter a name for encrypted file >>> ")
					while True:
						system("clear")
						Banner()

						File_Password=getpass.getpass(result)

						if len(File_Password) < 6:
							result = "\n\n\n\n\n\n\n\n\n\n\nThe password must not be less than 6 Enter again >>> "

							continue

						else:

							break


					result="\n\n>>> "+T7.Binary_File_Encryption(file_path,File_Password,Owt_File)
					system("clear")

					Banner()





				elif Select == "2":

						system ("clear")

						Banner()


						file_path = input("\n\n\n\n\n\n\n\n\n\n\nEnter file path >>> ")

						system("clear")

						result="\n\n\n\n\n\n\n\n\n\n\nEnter password >>> "
						system("clear")
						Banner()
						Owt_File=input("\n\n\n\n\n\n\n\n\n\n\nEnter a name for decrypted file >>> ")
						while True:

							system("clear")

							Banner()

							File_Password = getpass.getpass(result)

							if len(File_Password) < 6:

								result = "\n\n\n\n\n\n\n\n\n\n\nThe password must not be less than 6 Enter again >>> "

							else:

								break

						result="\n\n>>> "+T7.Binary_File_Decryption(file_path,File_Password,Owt_File)


						system("clear")

						Banner()





				elif Select == "3":

					system("clear")

					result = ""

					Banner()

					print(ops)

				elif Select == "0":

					system("clear")

					Banner()

					Options()

					break


				else:

					result = "\n\n>>> Wrong selection"


		system("clear")
		Banner()
		print(ops)
		try:
			print(result)
		except:
			pass
		Select = input("\n\nSelect >>> ")


		if Select == "1":
			Text_files_encryption()


		elif Select == "2":
			Other_files()

		elif Select == "3":
				system("clear")
				result = ""
				Banner()
				print(ops)


		elif Select == "0":
				system("clear")
				Banner()
				Options()
				break
		else:

				result = "\n\n>>> Wrong selection"



#=========main=========#




while True:

	system("clear")

	Banner()

	Options()

	try:

		print(result)

	except:

		pass
	try:
		Selection=input("\n\nSelect >>> ")
	except ValueError:
		system("clear")
		print("\nDo not modify the kernel or main file\n")
		exit()

	if Selection == "1":

		system("clear")

		Banner()

		Text = input("\n\n\n\n\n\n\n\n\n\n\n\nEnter text >>> ")

		while len(Text) < 4:

			system("clear")

			Banner()

			Text = input("\n\n\n\n\n\n\n\n\n\n\n\nThe text must be greater than 4 >>> ")

		system("clear")

		Banner()

		Password = getpass.getpass("\n\n\n\n\n\n\n\n\n\n\n\nEnter password >>> ")

		while len(Password) < 6:

			system("clear")

			Banner()

			Password = getpass.getpass("\n\n\n\n\n\n\n\n\n\n\n\nThe password must be larger than 6 >>> ")

		result="\n\n>>> "+ T7.Encryption(Text,Password)

		system("clear")

		Banner()

		Options()



	elif Selection == "2":

		system("clear")

		Banner()

		Code = input("\n\n\n\n\n\n\n\n\n\n\n\nEnter Code >>> ")

		while len(Code) < 4:

			system("clear")

			Banner()

			Code = input("\n\n\n\n\n\n\n\n\n\n\n\nThe text must be greater than 4 >>> ")

		system("clear")

		Banner()

		Password = getpass.getpass("\n\n\n\n\n\n\n\n\n\n\n\nEnte password >>> ")

		while len(Password) < 6:

			system("clear")

			Banner()

			Password = getpass.getpass("\n\n\n\n\n\n\n\n\n\n\n\nThe password must not be less than 6 >>> ")

		result ="\n\n>>> " +T7.Decryption(Code,Password)

		system("clear")

		Banner()

		Options()

		print("\n\n>>> " + result)



	elif Selection == "3":

		Selection_for_files()

	elif Selection == "4":

		system("rm -fr data/__pycache__")
		system("rm -fr __pycache__")
		system("clear")

		result="\n\n>>> Done"

		Banner()

		Options()

	elif Selection == "5":

		system("clear")

		result=""

		Banner()

		Options()

	elif Selection == "0":

		system("clear")

		exit()

	else:

		system("clear")

		Banner()

		Options()

		result="\n\n>>> Wrong selection"





#=========End of code=========#
#=========End of code=========#
#=========End of code=========#






#This script was created in 2023/4/12






#=========Donat ❤=========# 



"""

Bitcoin : 15Wf9rJSx94kb4cWKpt7ckM3t3TdWZ7rac


Litecoin : ltc1qjy7zr8and3ey8s2exnzc5z4lfm9r9ur40e3d2y


USDT (TRC20) : TQCwQoddNB7NdYu1R98RTKg6oDEBcp8UJK


Tron : TQCwQoddNB7NdYu1R98RTKg6oDEBcp8UJK

"""



#Thanks